package com.dimas.utsku;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText angka1,angka2;
    TextView output;
    Double v1,v2,hasil;
    Button btnexit, button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnexit = (Button)findViewById(R.id.button);
        btnexit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveTaskToBack(true);
                finish();
                System.exit(0);
            }
        });

        angka1 = (EditText) findViewById(R.id.inputpertama);
        angka2 = (EditText) findViewById(R.id.inputkedua);
        output = (TextView) findViewById(R.id.hasil);
    }

    public void konver(){
        //konversi inputan ke double
        v1 = Double.parseDouble(angka1.getText().toString());
        v2 = Double.parseDouble(angka2.getText().toString());
    }

    public void prosestambah(View view) {
        konver();
        hasil = v1+v2;  //perhitungan
        output.setText(Double.toString(hasil));  //output
    }

    public void proseskurang(View view) {
        konver();
        hasil = v1-v2;  //perhitungan
        output.setText(Double.toString(hasil));  //output
    }

    public void proseskali(View view) {
        konver();
        hasil = v1*v2;  //perhitungan
        output.setText(Double.toString(hasil));  //output
    }
    public void prosesbagi(View view) {
        konver();
        hasil = v1/v2;  //perhitungan
        output.setText(Double.toString(hasil));  //output
    }
}